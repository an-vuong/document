import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-extract-data',
  templateUrl: './extract-data.component.html',
  styleUrls: ['./extract-data.component.scss']
})
export class ExtractDataComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
