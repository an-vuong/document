import { Component, OnInit } from '@angular/core';
import { AiOcrService } from '../shared/ai-ocr.service';

@Component({
  selector: 'app-display-text',
  templateUrl: './display-text.component.html',
  styleUrls: ['./display-text.component.scss']
})
export class DisplayTextComponent implements OnInit {
  rawData: any;
  cutOffData: any;
  lines: any;

  constructor(private aiService: AiOcrService) {
    this.aiService = aiService;
  }

  ngOnInit(): void {
    this.rawData = this.aiService.getRawData();
    this.cutOffData = this.aiService.getCutOffData();
    this.lines = this.aiService.getLines();
  }

}
