export interface ICanvas {
  element: HTMLCanvasElement;
  context: CanvasRenderingContext2D;
  isDragged: boolean;
  isZoomable: boolean;
  isDraggable: boolean;
  isLoadedImg: boolean;
  mouseClickedPosition: IPosition;
  draggedDistance: IPosition;
}

export interface ISize {
  width: number;
  height: number;
}

export interface IPosition {
  x: number;
  y: number;
}

export const MAX_ZOOM_IN_RATIO = 3;
export const MAX_ZOOM_OUT_RATIO = 0.5;
export const ZOOM_RATIO_PER_WHEEL = 0.1;
