import { Component, OnInit } from '@angular/core';
import { AiOcrService } from '../shared/ai-ocr.service';

@Component({
  selector: 'app-menu',
  templateUrl: './menu.component.html',
  styleUrls: ['./menu.component.scss']
})
export class MenuComponent implements OnInit {

  receipts: any;

  constructor(private aiService: AiOcrService) {
    this.aiService = aiService;
  }

  ngOnInit(): void {
    return this.receipts = this.aiService.getReceipts();
  }

}
