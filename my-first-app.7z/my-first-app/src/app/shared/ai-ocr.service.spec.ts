import { TestBed } from '@angular/core/testing';

import { AiOcrService } from './ai-ocr.service';

describe('AiOcrService', () => {
  let service: AiOcrService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AiOcrService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
