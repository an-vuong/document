import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AiOcrService {
  ocrResult: any = {
    ocr_count: 1,
    ocr_data: {
      task_type: 'ocr',
      data: {
        result:
          'WRIGLEY GUM 002200000666 1.00 R \n0 MAILER 007535314740 0.77 X \nNOTEBOOK 078904124593 1.96 X \nTUB MERMAID 079118475981 5.96 X \nSPACE TUB 079118476006 5.96 X',
        words: [
          [
            {
              x4: 156,
              y2: 193,
              x3: 210,
              y4: 228,
              y1: 196,
              x1: 155,
              x2: 210,
              value: 'See',
              y3: 226,
              confidence: 1
            },
            {
              x4: 208,
              y2: 193,
              x3: 273,
              y4: 228,
              y1: 196,
              x1: 207,
              x2: 272,
              value: 'back',
              y3: 226,
              confidence: 1
            },
            {
              x4: 275,
              y2: 199,
              x3: 313,
              y4: 227,
              y1: 200,
              x1: 274,
              x2: 312,
              value: 'of',
              y3: 225,
              confidence: 1
            },
            {
              x4: 314,
              y2: 196,
              x3: 416,
              y4: 231,
              y1: 200,
              x1: 313,
              x2: 415,
              value: 'receipt',
              y3: 227,
              confidence: 1
            },
            {
              x4: 418,
              y2: 199,
              x3: 470,
              y4: 226,
              y1: 199,
              x1: 418,
              x2: 470,
              value: 'for',
              y3: 226,
              confidence: 0.9900000095367432
            },
            {
              x4: 470,
              y2: 198,
              x3: 536,
              y4: 227,
              y1: 200,
              x1: 469,
              x2: 535,
              value: 'your',
              y3: 225,
              confidence: 1
            },
            {
              x4: 540,
              y2: 200,
              x3: 630,
              y4: 231,
              y1: 200,
              x1: 540,
              x2: 630,
              value: 'chance',
              y3: 231,
              confidence: 1
            }
          ],
          [
            {
              x4: 160,
              y2: 221,
              x3: 194,
              y4: 246,
              y1: 222,
              x1: 159,
              x2: 193,
              value: 'to',
              y3: 244,
              confidence: 0.9599999785423279
            },
            {
              x4: 195,
              y2: 221,
              x3: 246,
              y4: 252,
              y1: 221,
              x1: 195,
              x2: 246,
              value: 'win',
              y3: 252,
              confidence: 1
            },
            {
              x4: 249,
              y2: 220,
              x3: 324,
              y4: 252,
              y1: 220,
              x1: 249,
              x2: 324,
              value: '$1000',
              y3: 252,
              confidence: 1
            },
            {
              x4: 327,
              y2: 221,
              x3: 365,
              y4: 252,
              y1: 221,
              x1: 327,
              x2: 365,
              value: 'ID',
              y3: 252,
              confidence: 1
            },
            {
              x4: 366,
              y2: 214,
              x3: 546,
              y4: 254,
              y1: 216,
              x1: 365,
              x2: 545,
              value: '#C7P75Ngao77',
              y3: 252,
              confidence: 0.4099999964237213
            }
          ],
          [],
          [
            {
              x4: 282,
              y2: 245,
              x3: 554,
              y4: 319,
              y1: 258,
              x1: 280,
              x2: 552,
              value: 'Walmart',
              y3: 306,
              confidence: 0.9900000095367432
            }
          ],
          [
            {
              x4: 182,
              y2: 298,
              x3: 348,
              y4: 336,
              y1: 302,
              x1: 181,
              x2: 347,
              value: '636-349-3116',
              y3: 331,
              confidence: 1
            },
            {
              x4: 344,
              y2: 289,
              x3: 643,
              y4: 339,
              y1: 296,
              x1: 343,
              x2: 642,
              value: 'Mar-CHRISTOFYER',
              y3: 331,
              confidence: 0.20000000298023224
            }
          ],
          [
            {
              x4: 243,
              y2: 327,
              x3: 291,
              y4: 354,
              y1: 327,
              x1: 243,
              x2: 291,
              value: '653',
              y3: 354,
              confidence: 0.9599999785423279
            },
            {
              x4: 295,
              y2: 324,
              x3: 401,
              y4: 356,
              y1: 328,
              x1: 294,
              x2: 400,
              value: 'GRAVOTS',
              y3: 353,
              confidence: 0.9599999785423279
            },
            {
              x4: 403,
              y2: 321,
              x3: 495,
              y4: 358,
              y1: 326,
              x1: 402,
              x2: 494,
              value: 'BLUFFS',
              y3: 354,
              confidence: 0.8500000238418579
            },
            {
              x4: 496,
              y2: 323,
              x3: 561,
              y4: 352,
              y1: 320,
              x1: 497,
              x2: 562,
              value: 'BLVD',
              y3: 355,
              confidence: 1
            }
          ],
          [
            {
              x4: 292,
              y2: 347,
              x3: 387,
              y4: 385,
              y1: 354,
              x1: 290,
              x2: 386,
              value: 'FENTON',
              y3: 379,
              confidence: 1
            },
            {
              x4: 388,
              y2: 349,
              x3: 424,
              y4: 380,
              y1: 352,
              x1: 387,
              x2: 423,
              value: 'MO',
              y3: 378,
              confidence: 0.9300000071525574
            },
            {
              x4: 428,
              y2: 346,
              x3: 505,
              y4: 383,
              y1: 351,
              x1: 427,
              x2: 504,
              value: '63026',
              y3: 379,
              confidence: 1
            }
          ],
          [
            {
              x4: 142,
              y2: 372,
              x3: 196,
              y4: 405,
              y1: 372,
              x1: 142,
              x2: 196,
              value: 'ST#',
              y3: 405,
              confidence: 1
            },
            {
              x4: 196,
              y2: 370,
              x3: 277,
              y4: 408,
              y1: 375,
              x1: 195,
              x2: 276,
              value: '00805',
              y3: 404,
              confidence: 1
            },
            {
              x4: 278,
              y2: 374,
              x3: 329,
              y4: 405,
              y1: 374,
              x1: 278,
              x2: 329,
              value: 'OP#',
              y3: 405,
              confidence: 0.9399999976158142
            },
            {
              x4: 330,
              y2: 371,
              x3: 422,
              y4: 409,
              y1: 377,
              x1: 329,
              x2: 421,
              value: '009028',
              y3: 404,
              confidence: 1
            },
            {
              x4: 424,
              y2: 373,
              x3: 479,
              y4: 406,
              y1: 375,
              x1: 423,
              x2: 478,
              value: 'TE#',
              y3: 404,
              confidence: 1
            },
            {
              x4: 485,
              y2: 374,
              x3: 517,
              y4: 400,
              y1: 376,
              x1: 484,
              x2: 516,
              value: '28',
              y3: 398,
              confidence: 0.9800000190734863
            },
            {
              x4: 525,
              y2: 374,
              x3: 574,
              y4: 401,
              y1: 374,
              x1: 525,
              x2: 574,
              value: 'TR#',
              y3: 401,
              confidence: 1
            },
            {
              x4: 579,
              y2: 373,
              x3: 658,
              y4: 405,
              y1: 373,
              x1: 579,
              x2: 658,
              value: '00532',
              y3: 405,
              confidence: 0.9900000095367432
            }
          ],
          [
            {
              x4: 142,
              y2: 397,
              x3: 248,
              y4: 431,
              y1: 400,
              x1: 141,
              x2: 247,
              value: 'WRIGLEY',
              y3: 429,
              confidence: 1
            },
            {
              x4: 250,
              y2: 399,
              x3: 301,
              y4: 429,
              y1: 401,
              x1: 249,
              x2: 300,
              value: 'GUM',
              y3: 428,
              confidence: 1
            },
            {
              x4: 318,
              y2: 394,
              x3: 492,
              y4: 435,
              y1: 401,
              x1: 317,
              x2: 491,
              value: '002200000666',
              y3: 429,
              confidence: 0.9900000095367432
            },
            {
              x4: 576,
              y2: 400,
              x3: 643,
              y4: 429,
              y1: 398,
              x1: 577,
              x2: 644,
              value: '1.00',
              y3: 430,
              confidence: 0.9700000286102295
            },
            {
              x4: 646,
              y2: 400,
              x3: 673,
              y4: 429,
              y1: 402,
              x1: 645,
              x2: 672,
              value: 'R',
              y3: 428,
              confidence: 1
            }
          ],
          [
            {
              x4: 153,
              y2: 424,
              x3: 178,
              y4: 451,
              y1: 424,
              x1: 153,
              x2: 178,
              value: '0',
              y3: 451,
              confidence: 1
            },
            {
              x4: 179,
              y2: 420,
              x3: 275,
              y4: 458,
              y1: 424,
              x1: 178,
              x2: 275,
              value: 'MAILER',
              y3: 454,
              confidence: 1
            },
            {
              x4: 314,
              y2: 418,
              x3: 489,
              y4: 461,
              y1: 427,
              x1: 313,
              x2: 488,
              value: '007535314740',
              y3: 453,
              confidence: 0.9900000095367432
            },
            {
              x4: 578,
              y2: 423,
              x3: 643,
              y4: 454,
              y1: 422,
              x1: 579,
              x2: 644,
              value: '0.77',
              y3: 455,
              confidence: 1
            },
            {
              x4: 647,
              y2: 423,
              x3: 673,
              y4: 455,
              y1: 423,
              x1: 647,
              x2: 673,
              value: 'X',
              y3: 455,
              confidence: 0.9900000095367432
            }
          ],
          [
            {
              x4: 134,
              y2: 445,
              x3: 257,
              y4: 483,
              y1: 450,
              x1: 133,
              x2: 257,
              value: 'NOTEBOOK',
              y3: 479,
              confidence: 0.9399999976158142
            },
            {
              x4: 309,
              y2: 445,
              x3: 490,
              y4: 486,
              y1: 453,
              x1: 308,
              x2: 489,
              value: '078904124593',
              y3: 479,
              confidence: 1
            },
            {
              x4: 581,
              y2: 449,
              x3: 644,
              y4: 480,
              y1: 449,
              x1: 581,
              x2: 644,
              value: '1.96',
              y3: 480,
              confidence: 1
            },
            {
              x4: 646,
              y2: 448,
              x3: 675,
              y4: 481,
              y1: 450,
              x1: 645,
              x2: 674,
              value: 'X',
              y3: 479,
              confidence: 1
            }
          ],
          [
            {
              x4: 137,
              y2: 473,
              x3: 188,
              y4: 504,
              y1: 473,
              x1: 137,
              x2: 188,
              value: 'TUB',
              y3: 504,
              confidence: 0.9599999785423279
            },
            {
              x4: 190,
              y2: 471,
              x3: 298,
              y4: 506,
              y1: 473,
              x1: 189,
              x2: 297,
              value: 'MERMAID',
              y3: 503,
              confidence: 1
            },
            {
              x4: 313,
              y2: 471,
              x3: 498,
              y4: 506,
              y1: 475,
              x1: 312,
              x2: 497,
              value: '079118475981',
              y3: 503,
              confidence: 1
            },
            {
              x4: 576,
              y2: 471,
              x3: 640,
              y4: 504,
              y1: 471,
              x1: 576,
              x2: 640,
              value: '5.96',
              y3: 504,
              confidence: 0.9900000095367432
            },
            {
              x4: 646,
              y2: 473,
              x3: 677,
              y4: 506,
              y1: 475,
              x1: 645,
              x2: 676,
              value: 'X',
              y3: 504,
              confidence: 1
            }
          ],
          [
            {
              x4: 138,
              y2: 498,
              x3: 212,
              y4: 529,
              y1: 498,
              x1: 138,
              x2: 212,
              value: 'SPACE',
              y3: 529,
              confidence: 1
            },
            {
              x4: 216,
              y2: 499,
              x3: 268,
              y4: 530,
              y1: 499,
              x1: 216,
              x2: 268,
              value: 'TUB',
              y3: 530,
              confidence: 1
            },
            {
              x4: 313,
              y2: 500,
              x3: 486,
              y4: 533,
              y1: 500,
              x1: 313,
              x2: 486,
              value: '079118476006',
              y3: 533,
              confidence: 1
            },
            {
              x4: 575,
              y2: 499,
              x3: 645,
              y4: 531,
              y1: 499,
              x1: 575,
              x2: 645,
              value: '5.96',
              y3: 531,
              confidence: 1
            },
            {
              x4: 647,
              y2: 498,
              x3: 676,
              y4: 533,
              y1: 501,
              x1: 645,
              x2: 674,
              value: 'X',
              y3: 530,
              confidence: 1
            }
          ],
          [
            {
              x4: 378,
              y2: 525,
              x3: 499,
              y4: 560,
              y1: 528,
              x1: 377,
              x2: 499,
              value: 'SUBTOTAL',
              y3: 557,
              confidence: 1
            },
            {
              x4: 563,
              y2: 526,
              x3: 640,
              y4: 557,
              y1: 524,
              x1: 564,
              x2: 641,
              value: '15.65',
              y3: 558,
              confidence: 0.9900000095367432
            }
          ],
          [
            {
              x4: 253,
              y2: 550,
              x3: 309,
              y4: 583,
              y1: 552,
              x1: 252,
              x2: 308,
              value: 'TAX',
              y3: 582,
              confidence: 1
            },
            {
              x4: 362,
              y2: 551,
              x3: 446,
              y4: 586,
              y1: 555,
              x1: 361,
              x2: 445,
              value: '9.238',
              y3: 582,
              confidence: 1
            },
            {
              x4: 448,
              y2: 554,
              x3: 473,
              y4: 585,
              y1: 554,
              x1: 448,
              x2: 473,
              value: '%',
              y3: 585,
              confidence: 1
            },
            {
              x4: 576,
              y2: 550,
              x3: 642,
              y4: 582,
              y1: 550,
              x1: 576,
              x2: 642,
              value: '1.35',
              y3: 582,
              confidence: 1
            }
          ],
          [
            {
              x4: 252,
              y2: 575,
              x3: 304,
              y4: 608,
              y1: 577,
              x1: 251,
              x2: 303,
              value: 'TAX',
              y3: 607,
              confidence: 1
            },
            {
              x4: 308,
              y2: 577,
              x3: 333,
              y4: 610,
              y1: 579,
              x1: 307,
              x2: 332,
              value: '2',
              y3: 608,
              confidence: 1
            },
            {
              x4: 363,
              y2: 577,
              x3: 441,
              y4: 610,
              y1: 579,
              x1: 362,
              x2: 440,
              value: '5.850',
              y3: 608,
              confidence: 0.9900000095367432
            },
            {
              x4: 451,
              y2: 581,
              x3: 471,
              y4: 608,
              y1: 581,
              x1: 451,
              x2: 471,
              value: '%',
              y3: 608,
              confidence: 1
            },
            {
              x4: 578,
              y2: 578,
              x3: 645,
              y4: 609,
              y1: 578,
              x1: 578,
              x2: 645,
              value: '0.06',
              y3: 609,
              confidence: 1
            }
          ],
          [
            {
              x4: 422,
              y2: 600,
              x3: 523,
              y4: 638,
              y1: 607,
              x1: 421,
              x2: 521,
              value: 'TOTAL',
              y3: 631,
              confidence: 1
            },
            {
              x4: 566,
              y2: 603,
              x3: 645,
              y4: 635,
              y1: 604,
              x1: 565,
              x2: 645,
              value: '17.06',
              y3: 633,
              confidence: 1
            }
          ],
          [
            {
              x4: 330,
              y2: 627,
              x3: 410,
              y4: 659,
              y1: 628,
              x1: 329,
              x2: 410,
              value: 'DEBIT',
              y3: 658,
              confidence: 1
            },
            {
              x4: 435,
              y2: 627,
              x3: 499,
              y4: 659,
              y1: 631,
              x1: 434,
              x2: 498,
              value: 'TEND',
              y3: 656,
              confidence: 1
            },
            {
              x4: 574,
              y2: 628,
              x3: 646,
              y4: 659,
              y1: 628,
              x1: 574,
              x2: 646,
              value: '17.06',
              y3: 659,
              confidence: 0.9800000190734863
            }
          ],
          [
            {
              x4: 343,
              y2: 650,
              x3: 439,
              y4: 684,
              y1: 653,
              x1: 342,
              x2: 438,
              value: 'CHANGE',
              y3: 682,
              confidence: 1
            },
            {
              x4: 446,
              y2: 649,
              x3: 498,
              y4: 685,
              y1: 653,
              x1: 445,
              x2: 497,
              value: 'DUE',
              y3: 682,
              confidence: 1
            },
            {
              x4: 577,
              y2: 650,
              x3: 648,
              y4: 684,
              y1: 653,
              x1: 576,
              x2: 647,
              value: '0.00',
              y3: 682,
              confidence: 1
            }
          ],
          [
            {
              x4: 116,
              y2: 678,
              x3: 172,
              y4: 712,
              y1: 680,
              x1: 115,
              x2: 171,
              value: 'EFT',
              y3: 711,
              confidence: 1
            },
            {
              x4: 171,
              y2: 677,
              x3: 249,
              y4: 711,
              y1: 677,
              x1: 171,
              x2: 249,
              value: 'DEBIT',
              y3: 711,
              confidence: 0.9900000095367432
            },
            {
              x4: 342,
              y2: 678,
              x3: 398,
              y4: 712,
              y1: 678,
              x1: 342,
              x2: 398,
              value: 'PAY',
              y3: 712,
              confidence: 1
            },
            {
              x4: 400,
              y2: 677,
              x3: 473,
              y4: 713,
              y1: 680,
              x1: 399,
              x2: 472,
              value: 'FROM',
              y3: 711,
              confidence: 1
            },
            {
              x4: 471,
              y2: 676,
              x3: 583,
              y4: 715,
              y1: 680,
              x1: 470,
              x2: 583,
              value: 'PRIMARY',
              y3: 711,
              confidence: 1
            }
          ],
          [
            {
              x4: 164,
              y2: 708,
              x3: 242,
              y4: 741,
              y1: 708,
              x1: 164,
              x2: 242,
              value: '17.06',
              y3: 741,
              confidence: 1
            },
            {
              x4: 260,
              y2: 707,
              x3: 341,
              y4: 741,
              y1: 707,
              x1: 260,
              x2: 341,
              value: 'TOTAL',
              y3: 741,
              confidence: 1
            },
            {
              x4: 344,
              y2: 704,
              x3: 468,
              y4: 742,
              y1: 704,
              x1: 344,
              x2: 468,
              value: 'PURCHASE',
              y3: 742,
              confidence: 1
            }
          ],
          [
            {
              x4: 114,
              y2: 737,
              x3: 200,
              y4: 769,
              y1: 736,
              x1: 114,
              x2: 201,
              value: 'Debit',
              y3: 770,
              confidence: 1
            },
            {
              x4: 328,
              y2: 743,
              x3: 397,
              y4: 768,
              y1: 745,
              x1: 327,
              x2: 396,
              value: '****',
              y3: 767,
              confidence: 1
            },
            {
              x4: 404,
              y2: 744,
              x3: 467,
              y4: 768,
              y1: 744,
              x1: 404,
              x2: 467,
              value: '****',
              y3: 768,
              confidence: 1
            },
            {
              x4: 477,
              y2: 745,
              x3: 540,
              y4: 768,
              y1: 745,
              x1: 477,
              x2: 540,
              value: '****',
              y3: 768,
              confidence: 1
            },
            {
              x4: 547,
              y2: 738,
              x3: 618,
              y4: 770,
              y1: 738,
              x1: 547,
              x2: 618,
              value: '4178',
              y3: 770,
              confidence: 1
            },
            {
              x4: 647,
              y2: 734,
              x3: 680,
              y4: 772,
              y1: 738,
              x1: 644,
              x2: 677,
              value: '0',
              y3: 769,
              confidence: 1
            }
          ],
          [
            {
              x4: 118,
              y2: 764,
              x3: 170,
              y4: 796,
              y1: 765,
              x1: 117,
              x2: 170,
              value: 'REF',
              y3: 795,
              confidence: 1
            },
            {
              x4: 177,
              y2: 765,
              x3: 201,
              y4: 796,
              y1: 765,
              x1: 177,
              x2: 201,
              value: '#',
              y3: 796,
              confidence: 1
            },
            {
              x4: 202,
              y2: 764,
              x3: 384,
              y4: 799,
              y1: 766,
              x1: 201,
              x2: 383,
              value: '006200000129',
              y3: 798,
              confidence: 0.9900000095367432
            }
          ],
          [
            {
              x4: 116,
              y2: 790,
              x3: 233,
              y4: 831,
              y1: 793,
              x1: 115,
              x2: 233,
              value: 'NETWORK',
              y3: 828,
              confidence: 1
            },
            {
              x4: 231,
              y2: 794,
              x3: 281,
              y4: 825,
              y1: 794,
              x1: 231,
              x2: 281,
              value: 'ID.',
              y3: 825,
              confidence: 1
            },
            {
              x4: 289,
              y2: 794,
              x3: 357,
              y4: 828,
              y1: 794,
              x1: 289,
              x2: 357,
              value: '0082',
              y3: 828,
              confidence: 1
            },
            {
              x4: 360,
              y2: 794,
              x3: 427,
              y4: 828,
              y1: 794,
              x1: 360,
              x2: 427,
              value: 'APPR',
              y3: 828,
              confidence: 1
            },
            {
              x4: 431,
              y2: 793,
              x3: 499,
              y4: 828,
              y1: 794,
              x1: 430,
              x2: 499,
              value: 'CODE',
              y3: 827,
              confidence: 1
            },
            {
              x4: 503,
              y2: 793,
              x3: 604,
              y4: 828,
              y1: 795,
              x1: 502,
              x2: 604,
              value: '621903',
              y3: 827,
              confidence: 1
            }
          ],
          [
            {
              x4: 117,
              y2: 821,
              x3: 201,
              y4: 855,
              y1: 824,
              x1: 116,
              x2: 200,
              value: 'Debit',
              y3: 852,
              confidence: 1
            }
          ],
          [
            {
              x4: 116,
              y2: 848,
              x3: 171,
              y4: 883,
              y1: 851,
              x1: 115,
              x2: 170,
              value: 'AID',
              y3: 881,
              confidence: 1
            },
            {
              x4: 172,
              y2: 846,
              x3: 381,
              y4: 882,
              y1: 847,
              x1: 172,
              x2: 380,
              value: 'A0000000042203',
              y3: 881,
              confidence: 0.9800000190734863
            }
          ],
          [
            {
              x4: 115,
              y2: 878,
              x3: 156,
              y4: 911,
              y1: 878,
              x1: 115,
              x2: 156,
              value: 'TC',
              y3: 911,
              confidence: 0.9900000095367432
            },
            {
              x4: 157,
              y2: 875,
              x3: 403,
              y4: 912,
              y1: 878,
              x1: 156,
              x2: 402,
              value: 'FIB11E3D8OD11AB8',
              y3: 910,
              confidence: 0.4300000071525574
            }
          ],
          [
            {
              x4: 114,
              y2: 906,
              x3: 170,
              y4: 940,
              y1: 908,
              x1: 113,
              x2: 169,
              value: '*NO',
              y3: 939,
              confidence: 0.9900000095367432
            },
            {
              x4: 170,
              y2: 900,
              x3: 327,
              y4: 946,
              y1: 908,
              x1: 169,
              x2: 326,
              value: 'SIGNATURE',
              y3: 939,
              confidence: 1
            }
          ],
          [
            {
              x4: 308,
              y2: 907,
              x3: 441,
              y4: 948,
              y1: 913,
              x1: 307,
              x2: 440,
              value: 'REQUIRED',
              y3: 943,
              confidence: 1
            }
          ],
          [
            {
              x4: 111,
              y2: 934,
              x3: 238,
              y4: 972,
              y1: 934,
              x1: 111,
              x2: 238,
              value: 'TERMINAL',
              y3: 972,
              confidence: 1
            },
            {
              x4: 241,
              y2: 939,
              x3: 271,
              y4: 970,
              y1: 939,
              x1: 241,
              x2: 271,
              value: '#',
              y3: 970,
              confidence: 1
            },
            {
              x4: 266,
              y2: 936,
              x3: 396,
              y4: 978,
              y1: 943,
              x1: 265,
              x2: 395,
              value: 'SC010382',
              y3: 972,
              confidence: 0.9200000166893005
            }
          ],
          [
            {
              x4: 239,
              y2: 968,
              x3: 367,
              y4: 1005,
              y1: 972,
              x1: 238,
              x2: 367,
              value: '03/02/20',
              y3: 1001,
              confidence: 1
            },
            {
              x4: 413,
              y2: 967,
              x3: 545,
              y4: 1007,
              y1: 969,
              x1: 412,
              x2: 544,
              value: '09:59:09',
              y3: 1006,
              confidence: 1
            }
          ],
          [
            {
              x4: 281,
              y2: 1001,
              x3: 308,
              y4: 1030,
              y1: 998,
              x1: 282,
              x2: 310,
              value: '#',
              y3: 1032,
              confidence: 1
            },
            {
              x4: 308,
              y2: 993,
              x3: 398,
              y4: 1036,
              y1: 998,
              x1: 307,
              x2: 397,
              value: 'ITEMS',
              y3: 1031,
              confidence: 1
            },
            {
              x4: 399,
              y2: 1001,
              x3: 469,
              y4: 1033,
              y1: 999,
              x1: 400,
              x2: 470,
              value: 'SOLD',
              y3: 1035,
              confidence: 1
            },
            {
              x4: 472,
              y2: 1000,
              x3: 499,
              y4: 1033,
              y1: 1002,
              x1: 471,
              x2: 498,
              value: '5',
              y3: 1031,
              confidence: 1
            }
          ],
          [
            {
              x4: 181,
              y2: 1027,
              x3: 236,
              y4: 1060,
              y1: 1027,
              x1: 181,
              x2: 236,
              value: 'TC#',
              y3: 1060,
              confidence: 0.9900000095367432
            },
            {
              x4: 236,
              y2: 1024,
              x3: 309,
              y4: 1059,
              y1: 1024,
              x1: 236,
              x2: 309,
              value: '8878',
              y3: 1059,
              confidence: 1
            },
            {
              x4: 310,
              y2: 1030,
              x3: 382,
              y4: 1060,
              y1: 1032,
              x1: 309,
              x2: 382,
              value: '8602',
              y3: 1059,
              confidence: 1
            },
            {
              x4: 384,
              y2: 1029,
              x3: 453,
              y4: 1064,
              y1: 1029,
              x1: 384,
              x2: 453,
              value: '9982',
              y3: 1064,
              confidence: 1
            },
            {
              x4: 458,
              y2: 1029,
              x3: 531,
              y4: 1065,
              y1: 1032,
              x1: 457,
              x2: 530,
              value: '9099',
              y3: 1063,
              confidence: 0.9800000190734863
            },
            {
              x4: 532,
              y2: 1031,
              x3: 606,
              y4: 1067,
              y1: 1034,
              x1: 531,
              x2: 605,
              value: '3913',
              y3: 1064,
              confidence: 1
            }
          ],
          [],
          [],
          [],
          [
            {
              x4: 107,
              y2: 1134,
              x3: 165,
              y4: 1168,
              y1: 1134,
              x1: 107,
              x2: 165,
              value: 'Low',
              y3: 1168,
              confidence: 0.9900000095367432
            },
            {
              x4: 167,
              y2: 1133,
              x3: 265,
              y4: 1168,
              y1: 1133,
              x1: 167,
              x2: 265,
              value: 'Prices',
              y3: 1168,
              confidence: 1
            },
            {
              x4: 272,
              y2: 1137,
              x3: 330,
              y4: 1168,
              y1: 1137,
              x1: 272,
              x2: 330,
              value: 'You',
              y3: 1168,
              confidence: 1
            },
            {
              x4: 332,
              y2: 1138,
              x3: 387,
              y4: 1172,
              y1: 1138,
              x1: 332,
              x2: 387,
              value: 'Can',
              y3: 1172,
              confidence: 1
            },
            {
              x4: 392,
              y2: 1137,
              x3: 488,
              y4: 1173,
              y1: 1140,
              x1: 391,
              x2: 487,
              value: 'Trust.',
              y3: 1171,
              confidence: 0.9399999976158142
            },
            {
              x4: 499,
              y2: 1144,
              x3: 583,
              y4: 1176,
              y1: 1144,
              x1: 499,
              x2: 583,
              value: 'Every',
              y3: 1176,
              confidence: 1
            },
            {
              x4: 586,
              y2: 1144,
              x3: 655,
              y4: 1180,
              y1: 1142,
              x1: 587,
              x2: 656,
              value: 'Day.',
              y3: 1181,
              confidence: 0.9900000095367432
            }
          ],
          [
            {
              x4: 218,
              y2: 1165,
              x3: 347,
              y4: 1197,
              y1: 1164,
              x1: 218,
              x2: 348,
              value: '03/02/20',
              y3: 1199,
              confidence: 1
            },
            {
              x4: 412,
              y2: 1167,
              x3: 541,
              y4: 1201,
              y1: 1167,
              x1: 412,
              x2: 541,
              value: '09:59:17',
              y3: 1201,
              confidence: 1
            }
          ]
        ],
        full_result:
          '  See back of receipt for your chance \n  to win $1000 ID #C7P75Ngao77 \n\n        Walmart \n   636-349-3116 Mar-CHRISTOFYER \n      653 GRAVOTS BLUFFS BLVD \n        FENTON MO 63026 \n  ST# 00805 OP# 009028 TE# 28 TR# 00532 \n  WRIGLEY GUM 002200000666    1.00 R \n  0 MAILER  007535314740     0.77 X \n NOTEBOOK   078904124593     1.96 X \n TUB MERMAID 079118475981    5.96 X \n SPACE TUB   079118476006    5.96 X \n           SUBTOTAL    15.65 \n      TAX   9.238 %     1.35 \n      TAX 2  5.850 %     0.06 \n             TOTAL   17.06 \n         DEBIT  TEND    17.06 \n          CHANGE DUE    0.00 \n EFT DEBIT     PAY FROM PRIMARY \n  17.06  TOTAL PURCHASE \n Debit      **** **** **** 4178  0 \n REF # 006200000129 \n NETWORK ID. 0082 APPR CODE 621903 \n Debit \n AID A0000000042203 \n TC FIB11E3D8OD11AB8 \n *NO SIGNATURE \n        REQUIRED \n TERMINAL # SC010382 \n     03/02/20   09:59:09 \n       # ITEMS SOLD 5 \n   TC# 8878 8602 9982 9099 3913 \n\n\n\n Low Prices You Can Trust. Every Day. \n    03/02/20   09:59:17 \n'
      },
      id: 252980987
    }
  };

  receipts: any = ["12345","23456","34567"];

  constructor() {}

  getRawData() {
    return this.ocrResult.ocr_data.data.full_result;
  }
  getCutOffData() {
    return this.ocrResult.ocr_data.data.result;
  }
  getLines() {
    return this.ocrResult.ocr_data.data.words;
  }
  getReceipts () {
      return this.receipts;
  }
}
