import { Component, OnInit, AfterViewInit } from '@angular/core';
import { ICanvas, IPosition, ISize, MAX_ZOOM_IN_RATIO, MAX_ZOOM_OUT_RATIO, ZOOM_RATIO_PER_WHEEL } from '../model/canvas.interface';

@Component({
  selector: 'app-receipt',
  templateUrl: './receipt.component.html',
  styleUrls: ['./receipt.component.scss']
})
export class ReceiptComponent implements OnInit, AfterViewInit {

  private img: HTMLImageElement = null;
  private canvas: ICanvas = {
    element: null,
    context: null,
    isDragged: false,
    isZoomable: false,
    isDraggable: false,
    isLoadedImg: false,
    mouseClickedPosition: null,
    draggedDistance: null
  };

  private imgSize: ISize = null;
  private imgPosition: IPosition = null;
  private mouseDistanceFromImagePosition: IPosition = {
    x: 0,
    y: 0
  };

  constructor() {
  }

  ngOnInit(): void {
  }

  ngAfterViewInit(): void {
    const canvasWrapper = document.getElementsByClassName('canvas-wrapper');
    const canvasWrapperPadding = 35;

    this.canvas.element = <HTMLCanvasElement>document.getElementById('canvas');
    this.canvas.element.width = canvasWrapper[0].clientWidth - canvasWrapperPadding;
    this.canvas.element.height = 775 - canvasWrapperPadding;
    this.canvas.context = this.canvas.element.getContext('2d');
    
    this.addDragHandleEventsForCanvas();
    this.addZoomHandleEventsForCanvas();

    this.img = new Image();
    this.img.src = 'http://10.10.15.61:9090/simple-file-service/get/?fileId=/dev/NPD/AI/Milestone2/Regex/Walmart/246251610.jpg';
    // this.img.src = 'https://image.shutterstock.com/image-photo/bright-spring-view-cameo-island-260nw-1048185397.jpg';
    this.img.addEventListener('load', (e: Event) => {
      this.drawImageInCanvas(e);
    });
  }

  private drawImageInCanvas(e: Event): void {
    this.canvas.isLoadedImg = true;

    this.imgSize = {
      width: this.img.width,
      height: this.img.height
    };

    this.imgPosition = {
      x: this.canvas.element.width / 2 - this.img.width / 2,
      y: this.canvas.element.height / 2 - this.img.height / 2
    };

    this.canvas.context.clearRect(0, 0, this.canvas.element.width, this.canvas.element.height);

    this.canvas.context.drawImage(this.img, this.imgPosition.x, this.imgPosition.y);
  }

  private handleCanvasMouseDownEvent(e: MouseEvent): void {
    if (!this.canvas.isLoadedImg) {
      return;
    }

    if (e.offsetX < this.imgPosition.x) {
      return;
    }

    if (e.offsetY < this.imgPosition.y) {
      return;
    }

    if (e.offsetX > this.imgPosition.x + this.imgSize.width) {
      return;
    }

    if (e.offsetY > this.imgPosition.y + this.imgSize.height) {
      return;
    }

    this.canvas.isDraggable = true;
    this.canvas.mouseClickedPosition = {
      x: e.offsetX,
      y: e.offsetY
    };
  }

  private handleCanvasMouseMoveEvent(e: MouseEvent): void {
    if (!this.canvas.isDraggable) {
      return;
    }

    this.canvas.isDragged = true;

    this.canvas.draggedDistance = {
      x: e.offsetX - this.canvas.mouseClickedPosition.x,
      y: e.offsetY - this.canvas.mouseClickedPosition.y
    };

    this.canvas.context.clearRect(0, 0, this.canvas.element.width, this.canvas.element.height);

    this.canvas.context.drawImage(
      this.img,
      this.imgPosition.x + this.canvas.draggedDistance.x,
      this.imgPosition.y + this.canvas.draggedDistance.y,
      this.imgSize.width,
      this.imgSize.height
    );
  }

  private handleCanvasMouseUpEvent(e: MouseEvent): void {
    if (this.canvas.isDragged) {
      this.imgPosition.x += this.canvas.draggedDistance.x;
      this.imgPosition.y += this.canvas.draggedDistance.y;
    }

    this.canvas.isDragged = false;
    this.canvas.isDraggable = false;
    this.mouseDistanceFromImagePosition.x = 0;
    this.mouseDistanceFromImagePosition.y = 0;
  }

  private handleCanvasZoomEvent(e: WheelEvent): void {
    event.preventDefault();

    if (!this.canvas.isLoadedImg || !this.canvas.isZoomable) {
      return;
    }

    let cannotZoomIn = false;
    let cannotZoomOut = false;

    if (this.imgSize.width >= this.img.width * MAX_ZOOM_IN_RATIO || this.imgSize.height >= this.img.height * MAX_ZOOM_IN_RATIO) {
      cannotZoomIn = true;
    }

    if (this.imgSize.width <= this.img.width * MAX_ZOOM_OUT_RATIO || this.imgSize.height <= this.img.height * MAX_ZOOM_OUT_RATIO) {
      cannotZoomOut = true;
    }

    if (e.deltaY > 0) {
      // zoom out
      this.imgSize.width -= cannotZoomOut ? 0 : this.imgSize.width * ZOOM_RATIO_PER_WHEEL;
      this.imgSize.height -= cannotZoomOut ? 0 : this.imgSize.height * ZOOM_RATIO_PER_WHEEL;

      this.imgPosition.x += cannotZoomOut ? 0 : (this.imgSize.width * ZOOM_RATIO_PER_WHEEL) / 2;
      this.imgPosition.y += cannotZoomOut ? 0 : (this.imgSize.height * ZOOM_RATIO_PER_WHEEL) / 2;
    } else {
      // zoom in
      this.imgSize.width += cannotZoomIn ? 0 : this.imgSize.width * ZOOM_RATIO_PER_WHEEL;
      this.imgSize.height += cannotZoomIn ? 0 : this.imgSize.height * ZOOM_RATIO_PER_WHEEL;

      this.imgPosition.x -= cannotZoomIn ? 0 : (this.imgSize.width * ZOOM_RATIO_PER_WHEEL) / 2;
      this.imgPosition.y -= cannotZoomIn ? 0 : (this.imgSize.height * ZOOM_RATIO_PER_WHEEL) / 2;
    }

    this.canvas.context.clearRect(0, 0, this.canvas.element.width, this.canvas.element.height);

    this.canvas.context.drawImage(this.img, this.imgPosition.x, this.imgPosition.y, this.imgSize.width, this.imgSize.height);
  }

  private addDragHandleEventsForCanvas(): void {
    this.canvas.element.addEventListener('mousedown', (e: MouseEvent) => {
      this.handleCanvasMouseDownEvent(e);
    });

    this.canvas.element.addEventListener('mousemove', (e: MouseEvent) => {
      this.handleCanvasMouseMoveEvent(e);
    });

    this.canvas.element.addEventListener('mouseup', (e: MouseEvent) => {
      this.handleCanvasMouseUpEvent(e);
    });

    this.canvas.element.addEventListener('mouseout', (e: MouseEvent) => {
      this.handleCanvasMouseUpEvent(e);
    });
  }

  private addZoomHandleEventsForCanvas(): void {
    const bodyTag = document.getElementsByTagName('body')[0];

    bodyTag.addEventListener('keydown', (e: KeyboardEvent) => {
      if (e.key == 'Control') {
        this.canvas.isZoomable = true;
      }
    });

    bodyTag.addEventListener('keyup', (e: KeyboardEvent) => {
      if (e.key == 'Control') {
        this.canvas.isZoomable = false;
      }
    });

    this.canvas.element.addEventListener('mousewheel', (e: WheelEvent) => {
      this.handleCanvasZoomEvent(e);
    });
  }
}
